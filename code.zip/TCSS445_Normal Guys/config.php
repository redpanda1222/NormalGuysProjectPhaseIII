<?php  
define('DBHOST', 'localhost'); 
define('DBNAME', 'GameStore'); 
define('DBUSER', 'testuser3'); 
define('DBPASS', 'mypassword'); 
define('DBCONNSTRING','mysql:dbname=GameStore;charset=utf8mb4'); 
?> 